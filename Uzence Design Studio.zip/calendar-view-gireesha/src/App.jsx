import CalendarView from "./components/Calendar/CalendarView";
import "./App.css";

export default function App() {
  return (
    <div className="app">
      <h1 className="app-title">📅 Calendar View</h1>
      <div className="container">
        <CalendarView />
      </div>
    </div>
  );
}
