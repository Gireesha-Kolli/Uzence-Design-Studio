export default function ActionModal({ hasEvent, onAdd, onEdit, onDelete, onClose }) {
  return (
    <div className="modal-overlay">
      <div className="modal">
        <h3>Select an action</h3>
        <div className="modal-buttons column">
          <button onClick={onAdd}>Add Event</button>
          {hasEvent && <button onClick={onEdit}>Edit Event</button>}
          {hasEvent && <button onClick={onDelete}>Delete Event</button>}
          <button className="cancel" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
