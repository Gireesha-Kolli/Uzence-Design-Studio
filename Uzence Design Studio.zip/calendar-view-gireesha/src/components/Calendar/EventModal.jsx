import { useState, useEffect } from "react";

export default function EventModal({ date, event, mode, onSave, onClose }) {
  const [title, setTitle] = useState("");
  const [color, setColor] = useState("#3b82f6");

  useEffect(() => {
    if (event) {
      setTitle(event.title);
      setColor(event.color);
    } else {
      setTitle("");
      setColor("#3b82f6");
    }
  }, [event]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    onSave({ date: date || event.date, title, color });
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h3>{mode === "edit" ? "Edit Event" : "Add Event"}</h3>
        <form onSubmit={handleSubmit}>
          <label>
            Event Title:
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </label>
          <label>
            Color:
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
            />
          </label>
          <div className="modal-buttons">
            <button type="submit">{mode === "edit" ? "Update" : "Add"}</button>
            <button type="button" onClick={onClose}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
