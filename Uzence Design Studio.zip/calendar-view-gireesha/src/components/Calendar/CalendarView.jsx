import { useState, useEffect } from "react";
import dayjs from "dayjs";

export default function CalendarView() {
  // Load from localStorage or default event
  const [events, setEvents] = useState(() => {
    const saved = localStorage.getItem("events");
    return saved
      ? JSON.parse(saved)
      : [{ date: "2025-11-09", title: "Deadline for the assignment", color: "#ef4444" }];
  });

  const [currentDate, setCurrentDate] = useState(dayjs());
  const [view, setView] = useState("month");
  const [modal, setModal] = useState(null); // { type: 'add' | 'edit', date, event? }
  const [form, setForm] = useState({ title: "", color: "#2563eb" });

  // Save to localStorage whenever events change
  useEffect(() => {
    localStorage.setItem("events", JSON.stringify(events));
  }, [events]);

  // Calendar calculations
  const startOfMonth = currentDate.startOf("month").startOf("week");
  const endOfMonth = currentDate.endOf("month").endOf("week");
  const startOfWeek = currentDate.startOf("week");
  const endOfWeek = currentDate.endOf("week");

  const days = [];
  let day = view === "month" ? startOfMonth.clone() : startOfWeek.clone();
  const end = view === "month" ? endOfMonth.clone() : endOfWeek.clone();

  while (day.isBefore(end, "day") || day.isSame(end, "day")) {
    days.push(day);
    day = day.add(1, "day");
  }

  // Navigation
  const changeMonth = (n) => setCurrentDate(currentDate.add(n, "month"));
  const changeWeek = (n) => setCurrentDate(currentDate.add(n, "week"));
  const handlePrev = () => (view === "month" ? changeMonth(-1) : changeWeek(-1));
  const handleNext = () => (view === "month" ? changeMonth(1) : changeWeek(1));

  // Event Handlers
  const handleAddEvent = (date) => {
    setModal({ type: "add", date });
    setForm({ title: "", color: "#2563eb" });
  };

  const handleEditEvent = (date, event) => {
    setModal({ type: "edit", date, event });
    setForm({ title: event.title, color: event.color });
  };

  const handleSave = () => {
    if (!form.title.trim()) return;
    if (modal.type === "add") {
      setEvents([...events, { date: modal.date, title: form.title, color: form.color }]);
    } else if (modal.type === "edit") {
      setEvents(
        events.map((e) =>
          e.date === modal.date && e.title === modal.event.title
            ? { ...e, title: form.title, color: form.color }
            : e
        )
      );
    }
    setModal(null);
  };

  const handleDelete = () => {
    setEvents(events.filter((e) => !(e.date === modal.date && e.title === modal.event.title)));
    setModal(null);
  };

  return (
    <div className="calendar">
      {/* Header */}
      <div className="calendar-header">
        <h2>{currentDate.format("MMMM YYYY")}</h2>
        <div className="controls">
          <button onClick={() => setCurrentDate(dayjs())}>Today</button>
          <button onClick={handlePrev}>◀</button>
          <button onClick={handleNext}>▶</button>
          <select value={view} onChange={(e) => setView(e.target.value)}>
            <option value="month">Month</option>
            <option value="week">Week</option>
          </select>
        </div>
      </div>

      {/* Weekday headers */}
      <div className="grid weekday-row">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
          <div key={d} className="day-header">
            {d}
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className={`grid calendar-grid ${view === "week" ? "week-view" : ""}`}>
        {days.map((day) => {
          const dayEvents = events.filter((e) => e.date === day.format("YYYY-MM-DD"));
          const isToday = day.isSame(dayjs(), "day");

          return (
            <div
              key={day.format("DD-MM-YYYY")}
              className={`day-cell ${isToday ? "today" : ""}`}
              onClick={() => handleAddEvent(day.format("YYYY-MM-DD"))}
            >
              <div className="day-number">{day.format("D")}</div>

              <div className="event-list">
                {dayEvents.map((event, i) => (
                  <div
                    key={i}
                    className="event"
                    style={{ backgroundColor: event.color }}
                    title={`${event.title} — ${day.format("MMM D, YYYY")}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditEvent(day.format("YYYY-MM-DD"), event);
                    }}
                  >
                    {event.title}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal */}
      {modal && (
        <div className="modal-overlay" onClick={() => setModal(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>{modal.type === "add" ? "Add Event" : "Edit Event"}</h3>
            <input
              type="text"
              placeholder="Event title"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
            <label>Color:</label>
            <input
              type="color"
              value={form.color}
              onChange={(e) => setForm({ ...form, color: e.target.value })}
            />
            <button onClick={handleSave}>
              {modal.type === "add" ? "Add Event" : "Update Event"}
            </button>
            {modal.type === "edit" && <button onClick={handleDelete}>Delete Event</button>}
          </div>
        </div>
      )}
    </div>
  );
}
