import React from "react";

export const CalendarCell = ({ date, events = [], currentDate, onEventClick }) => {
  const today = new Date();
  const isToday =
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear();
  const isCurrentMonth = date.getMonth() === currentDate.getMonth();

  return (
    <div
      className={`h-28 p-2 border border-gray-100 cursor-pointer transition-all duration-150 ${
        isToday
          ? "bg-blue-50 ring-2 ring-blue-400"
          : isCurrentMonth
          ? "bg-white"
          : "bg-gray-50 opacity-60"
      } hover:bg-blue-100`}
    >
      <div className="text-sm font-semibold text-gray-700">{date.getDate()}</div>
      <div className="mt-2 space-y-1">
        {events.slice(0, 2).map((e) => (
          <div
            key={e.id}
            onClick={(ev) => {
              ev.stopPropagation();
              onEventClick(e);
            }}
            className="text-xs px-2 py-0.5 rounded-md text-white truncate shadow-sm"
            style={{ backgroundColor: e.color || "#0ea5e9" }}
          >
            {e.title}
          </div>
        ))}
      </div>
    </div>
  );
};
