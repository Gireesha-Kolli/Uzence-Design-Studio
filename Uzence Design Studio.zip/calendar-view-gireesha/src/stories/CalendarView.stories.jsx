import CalendarView from "../components/Calendar/CalendarView";

export default {
  title: "Components/CalendarView",
  component: CalendarView,
};

export const Default = () => <CalendarView />;
